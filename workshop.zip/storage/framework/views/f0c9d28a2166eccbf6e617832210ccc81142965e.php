<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

  <!-- ! Hide app brand if navbar-full -->
  <div class="app-brand demo mb-4">
    <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
      <span class="app-brand-logo demo">
        <img src="<?php echo e(asset('assets/img/logo.png')); ?>" style="max-height: 55px">
        
      </span>
      
    </a>

    <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-autod-block d-xl-none">
      <i class="bx bx-chevron-left bx-sm align-middle"></i>
    </a>
  </div>

  <div class="menu-inner-shadow"></div>

  <ul class="menu-inner py-1">
    
    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => (request()->routeIs('home') || request()->routeIs('index')) ]) ?>">
      <a href="<?php echo e(route('home')); ?>" class="menu-link" >
        
        <i class="menu-icon tf-icons bx bx-home-circle"></i>
        
        <div> <?php echo app('translator')->get('Home'); ?> </div>
      </a>      
    </li>

    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => request()->routeIs('roads*') ]) ?>">
      <a href="<?php echo e(route('roads.index')); ?>" class="menu-link" >
        
        <i class='menu-icon bx bx-map-alt'></i>
        
        <div> <?php echo app('translator')->get('Routes'); ?> </div>
      </a>      
    </li>

    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => request()->routeIs('orders*') ]) ?>">
      <a href="<?php echo e(route('orders.index')); ?>" class="menu-link" >
        
        <i class='menu-icon bx bxs-calendar-check'></i>
        
        <div> <?php echo app('translator')->get('Orders'); ?> </div>
      </a>      
    </li>

    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => request()->routeIs('customers*') ]) ?>">
      <a href="<?php echo e(route('customers.index')); ?>" class="menu-link" >
        
        <i class='menu-icon bx bx-happy'></i>
        
        <div> <?php echo app('translator')->get('Customers'); ?> </div>
      </a>      
    </li>

    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => request()->routeIs('drivers*') ]) ?>">
      <a href="<?php echo e(route('drivers.index')); ?>" class="menu-link" >
        
        <i class='menu-icon bx bxs-car'></i>
        
        <div> <?php echo app('translator')->get('Technician'); ?> </div>
      </a>      
    </li>

    <li class="<?php echo \Illuminate\Support\Arr::toCssClasses(['menu-item', 'active' => request()->routeIs('users*') ]) ?>">
      <a href="<?php echo e(route('users.index')); ?>" class="menu-link" >
        
        <i class="menu-icon tf-icons bx bx-user-circle"></i>
        
        <div> <?php echo app('translator')->get('Admins'); ?> </div>
      </a>      
    </li>
  
    
    
    
  </ul>

</aside>
<?php /**PATH D:\work\freelancer\basha\workshop\resources\views/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>