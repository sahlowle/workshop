<div class="col-xxl">
    <div class="card mb-4">
      <div class="card-header d-flex align-items-center justify-content-between">
        <h5 class="mb-0"> <?php echo app('translator')->get('Route Details'); ?> </h5>
      </div>
      <div class="card-body">

          <div class="row mb-3 mt-3">
            <label class="col-sm-2 col-form-label" for="basic-default-company"><?php echo app('translator')->get("Driver"); ?></label>
            <div class="col-sm-10">
                <?php echo Form::select('driver_id',$drivers, null, ['required','class' => 'select2 form-control']); ?>

          </div>

          <div class="row mt-4">
            <label class="col-sm-2 col-form-label" for="basic-default-name"><?php echo app('translator')->get("Description"); ?></label>
            <div class="col-sm-10">
                <?php echo Form::textarea('description', null,  ['required','rows'=>3,'class' => 'form-control','placeholder'=>  trans("Description")]); ?>

            </div>
          </div>
          
          <div class="row justify-content-end">
            <div class="col-sm-10">
                <button class="btn btn-outline-primary m-2" >
                    <i class='bx bx-save' style="font-size: 1.5rem"></i>
                    <?php echo app('translator')->get("Save"); ?> 
                  </button>
            </div>
          </div>
      </div>
    </div>
  </div>

<?php /**PATH D:\work\freelancer\basha\workshop\resources\views/admin/roads/fields.blade.php ENDPATH**/ ?>