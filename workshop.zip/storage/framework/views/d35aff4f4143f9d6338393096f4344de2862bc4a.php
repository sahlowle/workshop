<div class="card mb-4">
  <div class="card-header d-flex align-items-center justify-content-between">
    <h5 class="mb-0"><?php echo e($title); ?> </h5>
  </div>

  <div class="row card-body">

    <div class="col-6">

      <div class="mb-3">
        <label class=" col-form-label" for="basic-default-name"><?php echo app('translator')->get("Address"); ?></label>
        <div class="col-sm-10">
          <?php echo Form::text('address', null, ['required','class' => 'form-control','placeholder'=> trans("Address")]); ?>

        </div>
      </div>

      <div class="mb-3">
        <label class=" col-form-label" for="basic-default-company"><?php echo app('translator')->get("Customer"); ?></label>
        <div class="col-sm-10">
          <?php echo Form::select('customer_id',$customers, null, ['required','class' => 'select2 form-control']); ?>

        </div>
      </div>

      <div class="mb-3">
        <label class=" col-form-label" for="basic-default-company"><?php echo app('translator')->get("Status"); ?></label>
        <div class="col-sm-10">
          <?php echo Form::select('status',orderStatus(), null, ['required','class' => 'select2 form-control']); ?>

        </div>
      </div>


    </div>
    
    <div class="col-6">

      

      <div class="mb-3">
        <label class=" col-form-label" for="basic-default-name"><?php echo app('translator')->get("Description"); ?></label>
        <div class="col-sm-10">
          <?php echo Form::textarea('description', null, ['required','rows'=>8,'class' => 'form-control','placeholder'=> trans("Description")]); ?>

        </div>
      </div>
      
      
    </div>
    

    <div class="col-12">
      <div class="mb-3">
        <hr>
        
        <?php
        $lat = 23.8859;
        $lng = 45.0792;
        if (isset($order)) {
              $lat = $order->lat;
              $lng = $order->lng;
        }
        ?>

        <?php if (isset($component)) { $__componentOriginalff175f4f1688a8c2cc39e18a0105173785d3b7d3 = $component; } ?>
<?php $component = App\View\Components\Map::resolve(['lat' => $lat,'lng' => $lng] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('map'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Map::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff175f4f1688a8c2cc39e18a0105173785d3b7d3)): ?>
<?php $component = $__componentOriginalff175f4f1688a8c2cc39e18a0105173785d3b7d3; ?>
<?php unset($__componentOriginalff175f4f1688a8c2cc39e18a0105173785d3b7d3); ?>
<?php endif; ?>

        <hr>
        <div class=" justify-content-end">
          <div class="col-sm-10">
            <button class="btn btn-outline-primary m-2">
              <i class='bx bx-save' style="font-size: 1.5rem"></i>
              <?php echo app('translator')->get("Save"); ?>
            </button>
          </div>
        </div>
      </div>
    </div>




  </div>
</div>
<?php /**PATH D:\work\freelancer\basha\workshop\resources\views/admin/orders/fields.blade.php ENDPATH**/ ?>