

<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('content'); ?>
<h4 class="fw-bold py-3 mb-4">
  <span class="text-muted fw-light"> <?php echo app('translator')->get("Orders"); ?> /</span> <?php echo app('translator')->get('List'); ?>
</h4>

<a class="btn btn-outline-primary m-2" href="<?php echo e(route('orders.create')); ?>">
  <i class='bx bx-plus' style="font-size: 1.5rem"></i>
  <?php echo app('translator')->get("Add New"); ?> 
</a>

<!-- Hoverable Table rows -->
<div class="card">
  <h5 class="card-header"> <?php echo app('translator')->get('Users'); ?> </h5>
  <div class="table-responsive text-nowrap p-4">
    <table class="table table-hover datatable">
      <thead>
        <tr>
          <th>#</th>
          <th> <?php echo app('translator')->get("Refrence No"); ?> </th>
          <th> <?php echo app('translator')->get("Customer"); ?> </th>
          <th> <?php echo app('translator')->get("Status"); ?> </th>
          <th> <?php echo app('translator')->get("Actions"); ?> </th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td> <?php echo e($loop->index + 1); ?>  </td>
          <td> <?php echo e($item->reference_no); ?>  </td>
          <td> <?php echo e($item->customer->name); ?>  </td>
          <td> <?php echo e($item->status_name); ?>  </td>
          <td>
            <a class="btn btn-outline-primary pl-1" href="<?php echo e(route('orders.show',$item->id)); ?>">
              <i class='bx bx-show' style="font-size: 1.2rem"></i>
              <?php echo app('translator')->get('Show'); ?>
            </a>

            <a class="btn btn-outline-success pl-1" href="<?php echo e(route('orders.edit',$item->id)); ?>">
              <i class='bx bx-edit' style="font-size: 1.2rem"></i>
              <?php echo app('translator')->get('Edit'); ?>
            </a>

            <button  class="btn btn-outline-danger pl-1" onclick="deleteForm('deleteForm<?php echo e($item->id); ?>')">
              <i class="bx bx-trash me-1"></i>
              <?php echo app('translator')->get('Delete'); ?>
              <form id="deleteForm<?php echo e($item->id); ?>" action="<?php echo e(route('orders.destroy',$item->id)); ?>" method="POST">
                <?php echo method_field("DELETE"); ?>
                <?php echo csrf_field(); ?>
            </form>
          </button>

           
          </td>
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
  <div class="m-3">
    <?php echo e($data->links()); ?>

  </div>
</div>
<!--/ Hoverable Table rows -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\work\freelancer\basha\workshop\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>