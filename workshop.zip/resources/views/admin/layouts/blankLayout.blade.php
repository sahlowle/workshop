@extends('admin.layouts.app' )

@section('layoutContent')

<!-- Content -->
@yield('content')
<!--/ Content -->

@endsection
